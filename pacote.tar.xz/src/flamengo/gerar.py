"""Orquestrador do Reel do canal do Flamengo.

    python -m src.flamengo.gerar --snapshot data/snapshot.json \
        --formato pos_jogo --out saida/reel.mp4

Formatos: situacao | pos_jogo. (noticia exige aprovação humana: não passa por aqui
sem o texto já reescrito e aprovado.)

Trava editorial: se o formato for pos_jogo e não houver partida FINISHED,
o script sai com código 3 e NÃO gera vídeo — o workflow entende como "hoje não".
"""
from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys
from pathlib import Path

from src.flamengo import roteiro, quadros
from src.flamengo.render import voz
from src.flamengo.render.cena import PRE_ROLL

RAIZ = Path(__file__).resolve().parents[2]


def gerar(snapshot: dict, formato: str, destino: Path) -> Path | None:
    if formato == "situacao":
        pauta = roteiro.situacao(snapshot)
    elif formato == "pos_jogo":
        pauta = roteiro.pos_jogo(snapshot)
    elif formato == "diario":
        pauta = snapshot["pauta"]            # pronta pelo src.flamengo.diario
    elif formato == "pos_jogo_v2":
        analise = snapshot["analise"]
        tabela = analise.get("tabela") or (snapshot.get("snapshot") or {}).get("tabela")
        pauta = roteiro.pos_jogo_v2(analise, tabela)
    else:
        raise SystemExit(f"formato desconhecido: {formato}")
    if pauta is None:
        print("[trava] sem partida encerrada e confirmada — nenhum vídeo hoje")
        return None

    pauta = quadros.dirigir(pauta)
    destino = destino.resolve()
    trab = destino.parent / f"trab_{destino.stem}"
    if pauta.get("motor") == "dupla" and os.environ.get("FLAMENGO_MOTOR") != "v1":
        return gerar_dupla(pauta, destino, trab, snapshot)
    audio = voz.narrar(pauta["batidas"], trab, RAIZ)

    conteudo = dict(pauta, segs=audio["segs"])
    (trab / "conteudo.json").write_text(json.dumps(conteudo, ensure_ascii=False),
                                        encoding="utf-8")

    env = dict(os.environ, FLAMENGO_TRAB=str(trab), PYTHONPATH=str(RAIZ))
    subprocess.run([sys.executable, "-m", "manim", "-r", "1080,1920", "--fps", "30",
                    "--disable_caching", "--media_dir", str(trab / "media"),
                    str(Path(__file__).parent / "render" / "cena.py"), "ReelFlamengo"],
                   check=True, cwd=RAIZ, env=env)
    mudo = next((trab / "media" / "videos").rglob("ReelFlamengo.mp4"))

    atraso = int(PRE_ROLL * 1000)
    subprocess.run(["ffmpeg", "-y", "-v", "error", "-i", str(mudo), "-i", str(audio["master"]),
                    "-filter_complex", f"[1:a]adelay={atraso}:all=1,apad[a]",
                    "-map", "0:v", "-map", "[a]",
                    "-c:v", "libx264", "-profile:v", "main", "-level", "4.0",
                    "-crf", "22", "-pix_fmt", "yuv420p", "-r", "30",
                    "-c:a", "aac", "-b:a", "160k", "-ar", "48000",
                    "-movflags", "+faststart", "-shortest", str(destino)], check=True)

    destino.with_suffix(".txt").write_text(pauta.get("legenda_post") or legenda_post(pauta, snapshot),
                                           encoding="utf-8")
    (destino.with_suffix(".json")).write_text(json.dumps({
        **pauta, "duracao_segundos": audio["segs"][-1]["fim"] + PRE_ROLL + 1.2,
        "voz": voz.PRESET_BIRA, "filtro": voz.FILTRO_BIRA,
        "falas": [b["fala"] for b in pauta["batidas"]], "publicado": False,
    }, ensure_ascii=False, indent=2), encoding="utf-8")
    return destino


def gerar_dupla(pauta: dict, destino: Path, trab: Path, snapshot: dict) -> Path:
    """Esquete Juninho x Primo Secador: vozes distintas, rig com gestos e
    reações, câmera plano/contraplano e acabamento de colagem (grão de papel)."""
    from src.flamengo.render import voz_dupla, papel
    audio = voz_dupla.narrar(pauta["batidas"], trab, RAIZ)
    conteudo = dict(pauta, segs=audio["segs"])
    (trab / "conteudo.json").write_text(json.dumps(conteudo, ensure_ascii=False), encoding="utf-8")
    env = dict(os.environ, FLAMENGO_TRAB=str(trab), PYTHONPATH=str(RAIZ))
    qualidade = os.environ.get("FLAMENGO_RES", "1080,1920")
    subprocess.run([sys.executable, "-m", "manim", "-r", qualidade, "--fps", "30",
                    "--disable_caching", "--media_dir", str(trab / "media"),
                    str(Path(__file__).parent / "render" / "cena_dupla.py"), "EsqueteDupla"],
                   check=True, cwd=RAIZ, env=env)
    mudo = next((trab / "media" / "videos").rglob("EsqueteDupla.mp4"))
    mudo = papel.aplicar_textura(mudo, trab / "mudo_papel.mp4")
    subprocess.run(["ffmpeg", "-y", "-v", "error", "-i", str(mudo), "-i", str(audio["master"]),
                    "-filter_complex", "[1:a]apad[a]", "-map", "0:v", "-map", "[a]",
                    "-c:v", "libx264", "-profile:v", "main", "-level", "4.0",
                    "-crf", "21", "-pix_fmt", "yuv420p", "-r", "30",
                    "-c:a", "aac", "-b:a", "160k", "-ar", "48000",
                    "-movflags", "+faststart", "-shortest", str(destino)], check=True)
    destino.with_suffix(".txt").write_text(pauta.get("legenda_post") or legenda_post(pauta, snapshot),
                                           encoding="utf-8")
    destino.with_suffix(".json").write_text(json.dumps({
        **pauta, "duracao_segundos": audio["segs"][-1]["fim"] + 1.4, "motor": "dupla",
        "vozes": {k: {kk: str(vv) for kk, vv in v.items()} for k, v in voz_dupla.VOZES.items()},
        "falas": [b["fala"] for b in pauta["batidas"]], "publicado": False,
    }, ensure_ascii=False, indent=2), encoding="utf-8")
    return destino


HASHTAGS = "#Flamengo #Mengão #NaçãoRubroNegra #Brasileirão #CRF"


def legenda_post(pauta: dict, snapshot: dict) -> str:
    """Legenda do post, montada só com o que está no roteiro (dado já checado)."""
    capa = pauta["capa"].replace("\n", " · ")
    linhas = [f"{capa} 🔴⚫", ""]
    for b in pauta["batidas"]:
        if b["tipo"] in ("placar", "nota", "mexida"):
            linhas.append(b["legenda"])
    pergunta = next((b["legenda"] for b in pauta["batidas"] if b["tipo"] == "pergunta"), None)
    cta = next((b["legenda"] for b in pauta["batidas"] if b["tipo"] == "cta"), None)
    linhas.append("")
    if pergunta:
        linhas.append(pergunta + " 👇")
    if cta:
        linhas.append(cta)
    linhas += ["", HASHTAGS]
    return "\n".join(linhas) + "\n"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--snapshot", help="snapshot do football-data (opcional no pos_jogo_v2)")
    ap.add_argument("--formato", choices=["situacao", "pos_jogo", "pos_jogo_v2", "diario"], default="situacao")
    ap.add_argument("--analise", help="data/analise.json do coletor (formato pos_jogo_v2)")
    ap.add_argument("--pauta", help="data/pauta_diario.json do src.flamengo.diario (formato diario)")
    ap.add_argument("--out", required=True)
    a = ap.parse_args()
    snap = json.loads(Path(a.snapshot).read_text(encoding="utf-8")) if a.snapshot else {}
    if a.formato == "pos_jogo_v2":
        if not a.analise:
            raise SystemExit("pos_jogo_v2 precisa de --analise")
        snap = {"snapshot": snap, "analise": json.loads(Path(a.analise).read_text(encoding="utf-8"))}
    if a.formato == "diario":
        if not a.pauta:
            raise SystemExit("diario precisa de --pauta")
        snap = {"pauta": json.loads(Path(a.pauta).read_text(encoding="utf-8"))}
    saida = gerar(snap, a.formato, Path(a.out))
    if saida is None:
        sys.exit(3)
    print(f"ok: {saida}")


if __name__ == "__main__":
    main()
